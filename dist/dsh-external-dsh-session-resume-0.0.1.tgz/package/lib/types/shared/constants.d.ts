/** Shared limits that must stay in sync with the official session-reference service. */
export declare const MAX_REFERENCES = 3;
