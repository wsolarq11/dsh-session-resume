/**
 * Canonical session URI encoding matching `@deepseek-ai/dsh-session-reference`.
 *
 * The official encoding is `dsh-session:<base64url(JSON.stringify(sessionId))>`
 * over UTF-8 bytes. A plain `btoa(JSON.stringify(id))` is not safe for
 * non-Latin-1 session ids, so this module converts UTF-8 bytes explicitly.
 */
export declare const SESSION_REFERENCE_SCHEME = "dsh-session:";
export declare function encodeSessionUri(sessionId: string): string;
export declare function decodeSessionPayload(payload: string): string | null;
export declare function decodeSessionUri(uri: string): string | null;
export declare function escapeLabel(label: string): string;
export declare function formatMention(sessionId: string, label: string): string;
