/**
 * Shared parsing for official session-log download URLs. The official client
 * builds `/api/session.export?sessionId=...&includeDescendants=true`, so this
 * parser intentionally accepts a host-less path as well as an absolute URL.
 */
export interface LogUrlHit {
    id: string;
    start: number;
    end: number;
}
export declare function parseLogUrl(raw: string, start: number): LogUrlHit | null;
export declare function findLogUrlMatch(text: string): LogUrlHit | null;
export declare function findLogUrlMatches(text: string): LogUrlHit[];
export declare function countDistinctLogSessions(text: string): number;
