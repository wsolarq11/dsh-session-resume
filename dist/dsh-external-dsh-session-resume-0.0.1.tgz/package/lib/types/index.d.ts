/**
 * @dsh-external/dsh-session-resume — host half.
 *
 * Two surfaces:
 * 1. `/session-resume/api` JSON routes used by the client header/dock UI.
 * 2. `agent/pre-step` rewrite: a direct user message containing a session-log
 *    download URL (`/api/session.export?sessionId=...`) is rewritten into the
 *    canonical `@[label](dsh-session:...)` mention. The official
 *    `session-reference` prepend listener runs before us, calls next() (which
 *    includes this listener), then prepares the returned messages, so the
 *    pasted archive URL automatically becomes a real cross-session snapshot.
 */
import type { Context } from '@deepseek-ai/cordis';
import { MAX_REFERENCES } from './shared/constants.js';
import { countDistinctLogSessions, findLogUrlMatch, findLogUrlMatches, parseLogUrl, type LogUrlHit } from './shared/session-url.js';
declare module '@deepseek-ai/cordis' {
    interface Events {
        'agent/pre-step'(payload: unknown, next: () => Promise<unknown>): Promise<unknown>;
    }
}
export declare const name = "@dsh-external/dsh-session-resume";
export declare const inject: string[];
export { MAX_REFERENCES };
type AppContext = Context & {
    webServer: {
        register(route: {
            kind: 'exact' | 'prefix';
            path: string;
            handler: (req: any, res: any) => void | Promise<void>;
        }): () => void;
    };
};
export interface SessionInfo {
    sessionId: string;
    label: string;
    mention: string;
}
export declare function encodeSessionUriForExport(sessionId: string): string;
export declare function decodeSessionPayloadForExport(payload: string): string | null;
export declare function formatMentionForExport(sessionId: string, label: string): string;
export { countDistinctLogSessions, findLogUrlMatch, findLogUrlMatches, parseLogUrl, type LogUrlHit, };
export declare function resolveSession(ctx: AppContext, sessionId: string): Promise<SessionInfo | null>;
export declare function resolveFromText(ctx: AppContext, text: string): Promise<SessionInfo | null>;
export declare function rewriteText(ctx: AppContext, text: string, targetAgentId: string): Promise<string>;
export declare function apply(ctx: AppContext): void;
export declare const resumeInstruction = "\u8BF7\u7EE7\u7EED\u8FD9\u4E2A\u4F1A\u8BDD\uFF1A\u5148\u9605\u8BFB\u4E0A\u9762\u5F15\u7528\u7684\u4F1A\u8BDD\u5FEB\u7167\uFF0C\u603B\u7ED3\u5DF2\u5B8C\u6210\u7684\u5DE5\u4F5C\u3001\u5F53\u524D\u72B6\u6001\u548C\u5269\u4F59\u4EFB\u52A1\uFF0C\u7136\u540E\u4ECE\u65AD\u70B9\u7EE7\u7EED\uFF0C\u4E0D\u8981\u8981\u6C42\u7528\u6237\u91CD\u590D\u7C98\u8D34\u65E5\u5FD7\u3002";
